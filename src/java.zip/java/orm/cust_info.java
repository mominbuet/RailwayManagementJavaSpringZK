/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package orm;

import javax.persistence.*;
/**
 *
 * @author Gunner
 */

@Entity
@Table(name="cust_info")
public class cust_info {
    @Id
    @Column(name="cust_id")
    
    private int id;
    
    @Column(name="cust_name")
    private String cust_name;
    
    @Column(name="ssn")
    private int ssn;
    
    @Column(name="password")
    private String password;

    public String getCust_name() {
        return cust_name;
    }

    public void setCust_name(String cust_name) {
        this.cust_name = cust_name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getSsn() {
        return ssn;
    }

    public void setSsn(int ssn) {
        this.ssn = ssn;
    }

    public cust_info() {
    }

    public cust_info(String cust_name, int ssn, String password) {
        
        this.cust_name = cust_name;
        this.ssn = ssn;
        this.password = password;
    }
    
    
}
