/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package orm;

/**
 *
 * @author Gunner
 */
public class journey_info {
    
}
