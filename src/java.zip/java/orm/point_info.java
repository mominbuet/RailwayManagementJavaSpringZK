/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package orm;

import javax.persistence.*;
/**
 *
 * @author Gunner
 */

@Entity
@Table(name="point_info")
public class point_info {

    @Id
    @Column(name="point_id")
    
    private int id;
    
    @Column(name="cord")
    private String cord;

    public String getCord() {
        return cord;
    }

    public void setCord(String cord) {
        this.cord = cord;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public point_info( String cord) {
        
        this.cord = cord;
    }
    
    public point_info() {
    }
    
}
