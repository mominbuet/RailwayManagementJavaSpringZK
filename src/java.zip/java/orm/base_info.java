/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package orm;

import javax.persistence.*;
/**
 *
 * @author Gunner
 */
@Entity
@Table(name="base_info")
public class base_info {

    @Id
    @Column(name="base_id")
    
    private int id;
    
    @Column(name="base_name")
    private String base_name;
    
    @Column(name="status")
    private boolean bool;
    
    @Column(name="type")
    private String type;
    
    @Column(name="loc")
    
    private point_info loc;

    public String getBase_name() {
        return base_name;
    }

    public void setBase_name(String base_name) {
        this.base_name = base_name;
    }

    public boolean isBool() {
        return bool;
    }

    public void setBool(boolean bool) {
        this.bool = bool;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public point_info getLoc() {
        return loc;
    }

    public void setLoc(point_info loc) {
        this.loc = loc;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public base_info( String base_name, boolean bool, String type, point_info loc) {
        
        this.base_name = base_name;
        this.bool = bool;
        this.type = type;
        this.loc = loc;
    }
    
    public base_info() {
    }
    
}
